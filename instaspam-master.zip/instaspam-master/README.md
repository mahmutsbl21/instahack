# 🌙 THT Instagram SPAM Atıcı
* Program artık desteklenmediğinden çalışmamakta!*


##  🔥 Nedir ?
Instagram'da belirlediğiniz bir hesabı "spam" şikayetleriyle askıya almanızı sağlar. Programın çalışması için güncel bir proxy listesi ve spam isteği yollayacak kullanıcılar gereklidir.

![Screenshot](https://raw.githubusercontent.com/tarik0/instaspam/master/dVCM8q.png)

 ## 💻 Kurulum

Kurulum videolarını ve konularını altta vermiş olduğum bağlantılardan bulabilirsiniz! **(Konu ve videoları hazırladığı için Akif Dora kardeşime teşekkür ediyorum!)**

[Windows](https://www.youtube.com/watch?v=pE-FJwHxSG8)
[Android (Termux)](https://www.youtube.com/watch?v=4hdLzZFOTyU)

## 🤔 Sıkça Sorulan Sorular

### # Kullanıcıların ID'sini nereden bulabiliriz?
[Buradaki](https://codeofaninja.com/tools/find-instagram-user-id) adresinden bulabilirsiniz.
### # Spam atmama rağmen hesap kapanmadı?

Hesapların **%100** kapanma garantisi **yoktur.**

### # Kullanıcılar doğru olduğu halde giriş yapılamıyor?

Hesaplarınız %90 doğrulamaya düşüyordur veya proxylerinizde sıkıntı vardır.

### # Kullanıcı dosyasını nasıl doldurmalıyım?
Her satıra 1 kullanıcı olacak şekilde ve **kullanici_adi sifre** formatında yazmalısınız. **(Örn. necmi_selim 123sifre12)**

### # Proxy dosyasını nasıl doldurmalıyım?
Her satıra 1 proxy olacak şekilde ve **ip: port** formatında yazmalısınız. **(Örn. 1.1.1.1:8080)**

### # Proxy normalde çalıştığı halde programda çalışmıyor!
Proxyleriniz **HTTPS** destekli olmalıdır aksi halde çalışmaz.

## 📞 İletişim

Forum dışındaki iletişim bilgilerim;

**Telegram:** @Hichigo06 
**Instagram:** @hichigo.exe

##  ⚖️ Lisans

Bu program **GPLv3** lisansı altındadır. Lütfen programı değiştirip kullanmadan önce alttaki bağlantıları okuyunuz!

https://tr.wikipedia.org/wiki/GNU_Genel_Kamu_Lisans%C4%B1
https://www.gnu.org/licenses/quick-guide-gplv3.html

**Program ile yapacağınız herhangi bir işlemden ben sorumlu değilim. Bu riski göz önüne alarak kullanın.**
